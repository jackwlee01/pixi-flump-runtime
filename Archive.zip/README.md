First version available for Haxe-PixiJs
